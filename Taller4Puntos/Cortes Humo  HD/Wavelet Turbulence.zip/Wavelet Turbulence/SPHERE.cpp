//////////////////////////////////////////////////////////////////////
// This file is part of Wavelet Turbulence.
// 
// Wavelet Turbulence is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// Wavelet Turbulence is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Wavelet Turbulence.  If not, see <http://www.gnu.org/licenses/>.
// 
// Copyright 2008 Theodore Kim and Nils Thuerey
// 
// SPHERE.cpp: implementation of the SPHERE class.
//
//////////////////////////////////////////////////////////////////////

#include "SPHERE.h"
#include <iostream>
using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SPHERE::SPHERE(float x, float y, float z, float radius) :
  _radius(radius)
{
  _center[0] = x;
  _center[1] = y;
  _center[2] = z;
}

SPHERE::SPHERE(float x_m, float y_m, float z_m,float x_ma, float y_ma, float z_ma):
_radius(0)
{
	_center[0] = 0;
	_center[1] = 0;
	_center[2] = 0;
	 x_min=x_m;
	 y_min=y_m;
	 z_min=z_m;
	 x_max=x_ma; 
	 y_max=y_ma;
	 z_max=z_ma;

}

SPHERE::~SPHERE()
{

}

bool SPHERE::inside(float x, float y, float z)
{
	if(x_min <= x &&  x <= x_max  )
	{		
		if(y_min <= y &&  y <= y_max  )
		{
			if(z_min <= z &&  z <= z_max  )
			{	
			return true;
			}
		}
	}
	return false;
}


